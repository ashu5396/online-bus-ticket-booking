//.each() method is used to iterate over the items in a jquery collection 
//where as $.each() method is used to iterate over javascript object or arrays


// // example of .each() method
// $(document).ready(function(){
//     var result='';
//     $('li').each(function(index, element){
//         result+=index+" "+$(element).text()+"<br>";
//     $('#output').html(result);
//     });
// });


//example of $.each() method. it is used to iterate over javascript object/arrays

// $(document).ready(function(){
//     var javascriptArray=[100,200,300,400];//javascript array so we will use $.each()
//     var result='';

//     $.each(javascriptArray,function(index,item){
//         result+=index+" "+item+"<br>";
//     })
        
//     $('#output').html(result);
//     });


  //example of $.each() method   to iterate over javascript Object

  $(document).ready(function(){
    var javascriptObject={
        "name":"Ashutosh",
        "id":123,
        "Age":23
         };//javascript Object so we will use $.each()
    var result='';

    $.each(javascriptObject,function(key,value){
        result+=key+" "+value+"<br>";
    })
        
    $('#output').html(result);
    });

