//whenever an event occurs like the click event,mouseover,mouseout etc.
//the relevet data of that event is placed into the event Object
//let us write the code to fetch the event data from the event Object
//below are the code written

$(document).ready(function(event){
    $('#btn').click(function(event){ //this will give click event details
        getEventDetails(event);
    }).mouseover(function(event){//this will give mouseover event details
        getEventDetails(event);
    }).mouseout(function(event){//this will give mouseout event details
        getEventDetails(event);
    });
    function getEventDetails(event)
    {
        var result='Event Type='+event.type+'<br> X='+event.pageX+'<br> Y='+event.pageY+'<br>Target Element='+event.target.type;
        $('#output').html(result);
    }
});