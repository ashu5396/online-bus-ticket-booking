//In this program we will see which mouse button is clicked i.e. whether it is left or right or scroll button
//when a mouse button is clicked, there are two events that are automatically triggered behind the scenes i.e.,mousedown and mouseup. when these event occures, the event objectis automatically passed to there respctive event handler method


//depending upon the browser, 'event.button' or 'event.which' properties of the event Object are used to determine which button is clicked

//IE8 and erlier versions use event.button property

// ____________________________________
// |Property      |   Code  |  Button  |
// |--------------|---------|----------|
// |              |   1     |  Left    |
// | event.button |   4     |  Middle  |
// |              |   2     |   Right  |
// -------------------------------------



//IE9 and later version and most other W3C compliant browsers use event.which property

// ____________________________________
// |Property      |   Code  |  Button  |
// |--------------|---------|----------|
// |              |   1     |  Left    |
// | event.which  |   2     |  Middle  |
// |              |   3     |  Right   |
// -------------------------------------



//below are the code
$(document).ready(function(){
    $('#btn').mousedown(function(){
        var whichButton;

switch(event.which){
    case 1: whichButton='Left Button Clicked'; break;
    case 2: whichButton='Middle Button Clicked'; break;
    case 3: whichButton='Right Button Clicked'; break;
}



$('#output').html(whichButton);
});


});