$(document).ready(function(){
    $('#upcoming_past').change(function(){
      
       $('#upcoming_past option:selected').each(function(){
            
        var result='';
        if($(this).val()=="upcoming")
            {
                $('#timeFinder').html("<option value='Select'>Select</option><option value='nexttfhours'>Next 24 Hours</option><option value='nextweek'>Next Week</option><option value='nextmonth'>Next Month</option><option value='nextthreemonth'>Next 3 Month</option>")
                $('#output2').html('');
            }
        
         else if($(this).val()=="past")
            {
                $('#timeFinder').html("<option value='Select'>Select</option><option value='past_one_month'>Past 1 Month</option><option value='past_two_months'>Past 2 Months</option><option value='past_three_months'>Past 3 Months</option><option value='past_one_Year'>2018</option><option value='past_two_Year'>2017</option><option value='past_three_Year'>2016</option>")
                $('#output2').html('')
            }
            // else if($(this).val()=="nextweek"){
            //     var milliseconds = new Date().getTime() + (24*7 * 60 * 60 * 1000);
               
            //     var result=new Date(milliseconds);

            // }
            // else if($(this).val()=="nextmonth"){
            //     var result=nextMonth();

            // }
            // else if($(this).val()=="nextthreemonth"){
            //     var result=nextThreeMonth();

            // }
            else 
            {
                var result='<b style="color:red;">*</b><bold style="color:red;">Please Select Either Upcoming or Past</bold>'
                $('#timeFinder').html("<option value='Select'>Select</option>")
                $('#output2').html('')
            }
            
            $('#output1').html('<div class="container"><b>'+result+'</b></div>');
       });




      
    });


    $('#timeFinder').change(function(){

        $('#timeFinder option:selected').each(function(){
            var result='';
            if($(this).val()=='nexttfhours')
            {
                var milliseconds = new Date().getTime() + (24 * 60 * 60 * 1000);
                var newDate=new Date(milliseconds);
                var result='Next 24 Hours From Now= '+'<font style="color:red;">' +newDate.toDateString()+'  ---  '+newDate.getHours()+':'+newDate.getMinutes()+':'+newDate.getSeconds()+'</font>';
            }
            if($(this).val()=='nextweek')
            {
                var milliseconds = new Date().getTime() + (24*7 * 60 * 60 * 1000);
               
               var result='Next Week= '+'<font style="color:red;">' +new Date(milliseconds)+'</font>';
            
            }
            if($(this).val()=='nextmonth')
            {
                result= new Date();
            }
            if($(this).val()=='nextthreemonth')
            {
                result= new Date();
            }
            $('#output2').html('<div class="container"><b style="margin-left: 232px;">'+result+'</b></div>');
        });


    });
    
});