// //In this example, we are going to see how to bind event handlers to the event

// //below are the code to bind event handlers to the evnt using bind() method.
// $(document).ready(function(event){
//     $('#btn').bind('click', function(){ //we are passing event as an argument which we later use to find the x and y cordinate at which the click happened 
//         $('#output').html('Button Clicked<br>'+'X='+event.pageX+'<br>Y='+event.pageY);

//     });

// });



//if we want to bind multiple event handlers to an event, we can do that
// below are the code


$(document).ready(function(){
    $('#btn').bind('click mouseover mouseout', function(){ 
        
        if(event.type=='click')
        {$('#output').html('Button Clicked<br>'+'X='+event.pageX+'<br>Y='+event.pageY);
         }
         else if(event.type=='mouseover')
         {
             $(this).addClass('ButtonStyle')
         }
         else{
            $(this).removeClass('ButtonStyle')
         
         }
    });

});
